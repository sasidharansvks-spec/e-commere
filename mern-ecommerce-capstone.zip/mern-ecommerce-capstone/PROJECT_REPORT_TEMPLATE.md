# Final eCommerce Store — Project Report

> This follows the assignment's suggested submission format. Fill in the bracketed placeholders, add screenshots, then export this as a PDF or Word document — the assignment requires **one single file**.

## Cover Page
- **Project Title:** Final eCommerce Store
- **Name:** [Your name]
- **Course:** Full Stack Development — Imarticus Learning
- **Submission Date:** [Date]

## Project Overview
A full-stack MERN (MongoDB, Express.js, React, Node.js) e-commerce application that lets users browse products, register and log in securely, manage a shopping cart, and complete a checkout flow with sandbox payment processing. The project demonstrates end-to-end integration between a React frontend, an Express/Node REST API, and a MongoDB database.

## Features
- User registration and login (JWT authentication, hashed passwords)
- Product listing with search and category filters
- Product details page
- Add to cart, update quantity, and remove from cart
- Checkout flow with shipping address and sandbox payment
- Order confirmation / order summary
- Order history for logged-in users
- Admin product management (add / edit / delete products)

## Tech Stack
- **Frontend:** React 18, React Router, Axios, Vite
- **Backend:** Node.js, Express.js
- **Database:** MongoDB with Mongoose
- **Authentication:** JWT + bcrypt
- **Payments:** Simulated sandbox/test-mode gateway (test card 4242 4242 4242 4242)
- **Deployment:** [e.g. Render for the backend, Vercel for the frontend]

## Frontend Overview
Built with React and React Router. Global state for authentication and the shopping cart is managed with React Context, with the cart persisted to `localStorage` so it survives a refresh. Axios handles all API calls, attaching the JWT automatically to authenticated requests via a request interceptor.

## Backend Overview
An Express REST API organized into models, controllers, routes, and middleware. JWT middleware protects private routes, and a second admin-check middleware protects the product-management endpoints. All prices and stock levels are recalculated and validated server-side at checkout rather than trusted from the client, so the total can't be tampered with.

## Database Structure Summary
- **User** — name, email, hashed password, `isAdmin` flag
- **Product** — name, description, image, category, brand, price, countInStock, rating
- **Order** — reference to the user, an array of order items (each referencing a product), shipping address, payment result, full price breakdown, and paid/delivered status

## Authentication Flow
1. A user registers or logs in → the backend verifies credentials (bcrypt) and issues a signed JWT.
2. The frontend stores the JWT and attaches it as a `Bearer` token on subsequent requests.
3. Protected backend routes verify the token and load the current user before continuing.
4. Admin-only routes additionally check the user's `isAdmin` flag.

## Payment Integration Summary
Checkout uses a simulated sandbox payment gateway that mirrors how test-mode card processors behave: it validates the card fields, "declines" one designated test card, and otherwise returns a mock authorization — without ever storing the full card number or CVV, only the card brand and last 4 digits (for display on the confirmation page). The backend recalculates the order total from the database before "charging," so the client can't manipulate prices.

## System Flow
`Browse products → add to cart → log in / register → checkout (address + payment) → order created & stock updated → order confirmation → order history`

## Screenshots
[Insert screenshots here: home / product listing, product details, cart, checkout, order confirmation, admin dashboard]

## GitHub Repository
[Your GitHub repo link]

## Deployment Link
[Your live frontend URL]

## Challenges Faced
[For example: handling JWT expiry gracefully, keeping the cart in sync with live stock levels, structuring the checkout price calculation so it can't be manipulated from the client, configuring CORS between a separately-deployed frontend and backend...]

## Reflection
[What you learned building this end-to-end, and what you'd add next — e.g. a real payment gateway integration, product reviews, order tracking, a wishlist...]
