import { Link } from 'react-router-dom';

const ProductCard = ({ product }) => {
  return (
    <Link to={`/product/${product._id}`} className="product-card">
      <div className="product-card-image">
        <img src={product.image} alt={product.name} loading="lazy" />
      </div>
      <div className="product-card-body">
        <span className="product-category">{product.category}</span>
        <h3>{product.name}</h3>
        <div className="product-card-footer">
          <span className="price">${product.price.toFixed(2)}</span>
          <span className={`stock ${product.countInStock === 0 ? 'out' : ''}`}>
            {product.countInStock === 0 ? 'Out of stock' : `${product.countInStock} in stock`}
          </span>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
