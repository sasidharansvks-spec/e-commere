const Message = ({ type = 'info', children }) => (
  <div className={`message message-${type}`} role={type === 'error' ? 'alert' : 'status'}>
    {children}
  </div>
);

export default Message;
