import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const Navbar = () => {
  const { userInfo, logout } = useAuth();
  const { itemsCount } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="brand">
          Final eCommerce Store
        </Link>
        <nav className="nav-links">
          <Link to="/cart">Cart ({itemsCount})</Link>
          {userInfo ? (
            <>
              <Link to="/myorders">My Orders</Link>
              {userInfo.isAdmin && <Link to="/admin/products">Admin</Link>}
              <span className="nav-user">Hi, {userInfo.name.split(' ')[0]}</span>
              <button type="button" className="link-button" onClick={handleLogout}>
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login">Login</Link>
              <Link to="/register">Register</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
