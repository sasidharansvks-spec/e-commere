import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../api/axios';
import ProductCard from '../components/ProductCard';
import Loader from '../components/Loader';
import Message from '../components/Message';

const CATEGORIES = ['All', 'Electronics', 'Fashion', 'Home & Living', 'Books'];

const Home = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchParams, setSearchParams] = useSearchParams();

  const keyword = searchParams.get('keyword') || '';
  const category = searchParams.get('category') || 'All';

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const params = {};
        if (keyword) params.keyword = keyword;
        if (category !== 'All') params.category = category;
        const { data } = await api.get('/products', { params });
        setProducts(data);
        setError('');
      } catch (err) {
        setError(err.response?.data?.message || 'Could not load products. Is the API running?');
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, [keyword, category]);

  const handleSearch = (e) => {
    e.preventDefault();
    const value = e.target.elements.keyword.value.trim();
    const next = {};
    if (value) next.keyword = value;
    if (category !== 'All') next.category = category;
    setSearchParams(next);
  };

  const selectCategory = (cat) => {
    const next = {};
    if (keyword) next.keyword = keyword;
    if (cat !== 'All') next.category = cat;
    setSearchParams(next);
  };

  return (
    <div className="container">
      <div className="home-header">
        <div>
          <h1>Good things, well chosen.</h1>
          <p className="subhead">
            A small, well-curated selection across electronics, fashion, home, and books.
          </p>
        </div>
        <form onSubmit={handleSearch} className="search-form">
          <input name="keyword" defaultValue={keyword} placeholder="Search products..." />
          <button type="submit">Search</button>
        </form>
      </div>

      <div className="category-filter">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            className={cat === category ? 'active' : ''}
            onClick={() => selectCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      {loading ? (
        <Loader />
      ) : error ? (
        <Message type="error">{error}</Message>
      ) : products.length === 0 ? (
        <Message type="info">No products matched your search.</Message>
      ) : (
        <div className="product-grid">
          {products.map((product) => (
            <ProductCard key={product._id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;
