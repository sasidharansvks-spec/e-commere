import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useCart } from '../context/CartContext';
import Loader from '../components/Loader';
import Message from '../components/Message';

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [added, setAdded] = useState(false);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        setLoading(true);
        const { data } = await api.get(`/products/${id}`);
        setProduct(data);
        setQty(1);
      } catch (err) {
        setError(err.response?.data?.message || 'Product not found');
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  const handleAddToCart = () => {
    addToCart(product, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  if (loading) return <Loader />;
  if (error) return <div className="container"><Message type="error">{error}</Message></div>;
  if (!product) return null;

  return (
    <div className="container">
      <button type="button" className="back-link" onClick={() => navigate(-1)}>
        ← Back
      </button>
      <div className="product-details">
        <div className="product-details-image">
          <img src={product.image} alt={product.name} />
        </div>
        <div className="product-details-info">
          <span className="product-category">{product.category}</span>
          <h1>{product.name}</h1>
          <p className="product-brand">Brand: {product.brand}</p>
          <p className="rating">
            ⭐ {product.rating.toFixed(1)} ({product.numReviews} reviews)
          </p>
          <p className="description">{product.description}</p>

          <div className="product-details-card">
            <div className="row">
              <span>Price</span>
              <strong>${product.price.toFixed(2)}</strong>
            </div>
            <div className="row">
              <span>Status</span>
              <strong>{product.countInStock > 0 ? 'In stock' : 'Out of stock'}</strong>
            </div>
            {product.countInStock > 0 && (
              <div className="row">
                <span>Quantity</span>
                <select value={qty} onChange={(e) => setQty(Number(e.target.value))}>
                  {[...Array(Math.min(product.countInStock, 10)).keys()].map((x) => (
                    <option key={x + 1} value={x + 1}>
                      {x + 1}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <button
              type="button"
              className="btn btn-primary full-width"
              disabled={product.countInStock === 0}
              onClick={handleAddToCart}
            >
              {product.countInStock === 0 ? 'Out of stock' : added ? 'Added ✓' : 'Add to Cart'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
