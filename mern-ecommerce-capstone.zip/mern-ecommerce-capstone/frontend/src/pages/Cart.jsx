import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import Message from '../components/Message';

const Cart = () => {
  const { cartItems, updateQuantity, removeFromCart, itemsPrice } = useCart();
  const navigate = useNavigate();

  const handleCheckout = () => {
    navigate('/checkout');
  };

  return (
    <div className="container">
      <h1>Your Cart</h1>
      {cartItems.length === 0 ? (
        <Message type="info">
          Your cart's empty. Let's fix that — <Link to="/">browse the store</Link>.
        </Message>
      ) : (
        <div className="cart-layout">
          <div className="cart-items">
            {cartItems.map((item) => (
              <div className="cart-item" key={item.product}>
                <img src={item.image} alt={item.name} />
                <div className="cart-item-info">
                  <Link to={`/product/${item.product}`}>{item.name}</Link>
                  <span className="muted">${item.price.toFixed(2)} each</span>
                </div>
                <select
                  value={item.quantity}
                  onChange={(e) => updateQuantity(item.product, Number(e.target.value))}
                >
                  {[...Array(Math.max(item.countInStock, item.quantity, 1)).keys()].map((x) => (
                    <option key={x + 1} value={x + 1}>
                      {x + 1}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  className="link-button danger"
                  onClick={() => removeFromCart(item.product)}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
          <div className="cart-summary">
            <h2>Order Summary</h2>
            <div className="row">
              <span>Items</span>
              <span>${itemsPrice.toFixed(2)}</span>
            </div>
            <p className="muted small">Shipping and tax are calculated at checkout.</p>
            <button type="button" className="btn btn-primary full-width" onClick={handleCheckout}>
              Proceed to Checkout
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
