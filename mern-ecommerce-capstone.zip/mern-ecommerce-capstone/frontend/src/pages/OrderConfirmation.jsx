import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api/axios';
import Loader from '../components/Loader';
import Message from '../components/Message';

const OrderConfirmation = () => {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        setLoading(true);
        const { data } = await api.get(`/orders/${id}`);
        setOrder(data);
      } catch (err) {
        setError(err.response?.data?.message || 'Order not found');
      } finally {
        setLoading(false);
      }
    };
    fetchOrder();
  }, [id]);

  if (loading) return <Loader />;
  if (error) return <div className="container"><Message type="error">{error}</Message></div>;
  if (!order) return null;

  return (
    <div className="container">
      <div className="order-confirmation-banner">
        <h1>Order placed</h1>
        <p>Thank you — your order has been received and paid for.</p>
      </div>

      <div className="order-grid">
        <div>
          <h2>Order #{order._id.slice(-8).toUpperCase()}</h2>
          <p className="muted">Placed on {new Date(order.createdAt).toLocaleString()}</p>

          <h3>Shipping</h3>
          <p>
            {order.shippingAddress.address}, {order.shippingAddress.city}{' '}
            {order.shippingAddress.postalCode}, {order.shippingAddress.country}
          </p>
          <p>
            Status: <strong>{order.status}</strong>
          </p>

          <h3>Payment</h3>
          <p>
            {order.paymentResult?.cardBrand} ending in {order.paymentResult?.last4} —{' '}
            {order.isPaid ? `paid on ${new Date(order.paidAt).toLocaleString()}` : 'not paid'}
          </p>

          <h3>Items</h3>
          <div className="order-items">
            {order.orderItems.map((item) => (
              <div className="order-item" key={item.product}>
                <img src={item.image} alt={item.name} />
                <Link to={`/product/${item.product}`}>{item.name}</Link>
                <span>
                  {item.quantity} × ${item.price.toFixed(2)} = $
                  {(item.quantity * item.price).toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="cart-summary">
          <h2>Order Total</h2>
          <div className="row">
            <span>Items</span>
            <span>${order.itemsPrice.toFixed(2)}</span>
          </div>
          <div className="row">
            <span>Shipping</span>
            <span>${order.shippingPrice.toFixed(2)}</span>
          </div>
          <div className="row">
            <span>Tax</span>
            <span>${order.taxPrice.toFixed(2)}</span>
          </div>
          <div className="row total">
            <span>Total</span>
            <span>${order.totalPrice.toFixed(2)}</span>
          </div>
          <Link to="/" className="btn btn-primary full-width">
            Continue Shopping
          </Link>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmation;
