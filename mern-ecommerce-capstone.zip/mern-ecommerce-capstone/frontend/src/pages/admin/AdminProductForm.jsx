import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../../api/axios';
import Loader from '../../components/Loader';
import Message from '../../components/Message';

const emptyProduct = {
  name: '',
  price: '',
  image: '',
  brand: '',
  category: '',
  countInStock: '',
  description: '',
};

const AdminProductForm = () => {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const [product, setProduct] = useState(emptyProduct);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isEdit) return;
    const fetchProduct = async () => {
      try {
        const { data } = await api.get(`/products/${id}`);
        setProduct(data);
      } catch (err) {
        setError(err.response?.data?.message || 'Could not load product');
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id, isEdit]);

  const handleChange = (e) => {
    setProduct((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSaving(true);
    const payload = {
      ...product,
      price: Number(product.price),
      countInStock: Number(product.countInStock),
    };
    try {
      if (isEdit) {
        await api.put(`/products/${id}`, payload);
      } else {
        await api.post('/products', payload);
      }
      navigate('/admin/products');
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save product');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loader />;

  return (
    <div className="container narrow">
      <Link to="/admin/products" className="back-link">
        ← Back to products
      </Link>
      <h1>{isEdit ? 'Edit Product' : 'Add Product'}</h1>
      {error && <Message type="error">{error}</Message>}
      <form onSubmit={handleSubmit} className="form">
        <label>
          Name
          <input name="name" value={product.name} onChange={handleChange} required />
        </label>
        <label>
          Image URL
          <input name="image" value={product.image} onChange={handleChange} required />
        </label>
        <div className="form-row">
          <label>
            Price
            <input
              type="number"
              step="0.01"
              min="0"
              name="price"
              value={product.price}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            Count in stock
            <input
              type="number"
              min="0"
              name="countInStock"
              value={product.countInStock}
              onChange={handleChange}
              required
            />
          </label>
        </div>
        <div className="form-row">
          <label>
            Category
            <input name="category" value={product.category} onChange={handleChange} required />
          </label>
          <label>
            Brand
            <input name="brand" value={product.brand} onChange={handleChange} />
          </label>
        </div>
        <label>
          Description
          <textarea
            name="description"
            value={product.description}
            onChange={handleChange}
            rows={4}
            required
          />
        </label>
        <button type="submit" className="btn btn-primary full-width" disabled={saving}>
          {saving ? 'Saving...' : isEdit ? 'Save Changes' : 'Create Product'}
        </button>
      </form>
    </div>
  );
};

export default AdminProductForm;
