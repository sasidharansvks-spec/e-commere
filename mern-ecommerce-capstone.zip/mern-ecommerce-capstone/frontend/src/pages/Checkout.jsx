import { useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import api from '../api/axios';
import { useCart } from '../context/CartContext';
import Message from '../components/Message';

const Checkout = () => {
  const { cartItems, itemsPrice, clearCart } = useCart();
  const navigate = useNavigate();

  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [country, setCountry] = useState('');

  const [cardName, setCardName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const shippingPrice = itemsPrice > 100 ? 0 : 9.99;
  const taxPrice = Number((0.08 * itemsPrice).toFixed(2));
  const totalPrice = Number((itemsPrice + shippingPrice + taxPrice).toFixed(2));

  if (cartItems.length === 0) {
    return <Navigate to="/" replace />;
  }

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { data } = await api.post('/orders', {
        orderItems: cartItems,
        shippingAddress: { address, city, postalCode, country },
        paymentMethod: 'Sandbox Card',
        card: { cardName, cardNumber, expiry, cvv },
      });
      clearCart();
      navigate(`/order/${data._id}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not place order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>Checkout</h1>
      {error && <Message type="error">{error}</Message>}
      <form onSubmit={handlePlaceOrder} className="checkout-layout">
        <div className="checkout-forms">
          <fieldset>
            <legend>Shipping address</legend>
            <label>
              Street address
              <input value={address} onChange={(e) => setAddress(e.target.value)} required />
            </label>
            <div className="form-row">
              <label>
                City
                <input value={city} onChange={(e) => setCity(e.target.value)} required />
              </label>
              <label>
                Postal code
                <input value={postalCode} onChange={(e) => setPostalCode(e.target.value)} required />
              </label>
            </div>
            <label>
              Country
              <input value={country} onChange={(e) => setCountry(e.target.value)} required />
            </label>
          </fieldset>

          <fieldset>
            <legend>Payment — sandbox / test mode</legend>
            <p className="muted small">
              This is a simulated payment gateway for demo purposes; no real card is charged. Use{' '}
              <strong>4242 4242 4242 4242</strong> for a successful payment, or{' '}
              <strong>4000 0000 0000 0002</strong> to see a decline.
            </p>
            <label>
              Name on card
              <input value={cardName} onChange={(e) => setCardName(e.target.value)} required />
            </label>
            <label>
              Card number
              <input
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
                placeholder="4242 4242 4242 4242"
                required
              />
            </label>
            <div className="form-row">
              <label>
                Expiry (MM/YY)
                <input
                  value={expiry}
                  onChange={(e) => setExpiry(e.target.value)}
                  placeholder="12/28"
                  required
                />
              </label>
              <label>
                CVV
                <input value={cvv} onChange={(e) => setCvv(e.target.value)} placeholder="123" required />
              </label>
            </div>
          </fieldset>
        </div>

        <div className="cart-summary">
          <h2>Order Summary</h2>
          <div className="row">
            <span>Items</span>
            <span>${itemsPrice.toFixed(2)}</span>
          </div>
          <div className="row">
            <span>Shipping</span>
            <span>{shippingPrice === 0 ? 'Free' : `$${shippingPrice.toFixed(2)}`}</span>
          </div>
          <div className="row">
            <span>Tax</span>
            <span>${taxPrice.toFixed(2)}</span>
          </div>
          <div className="row total">
            <span>Total</span>
            <span>${totalPrice.toFixed(2)}</span>
          </div>
          <button type="submit" className="btn btn-primary full-width" disabled={loading}>
            {loading ? 'Placing order...' : 'Place Order & Pay'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default Checkout;
