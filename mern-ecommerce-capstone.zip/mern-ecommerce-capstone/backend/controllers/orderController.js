import asyncHandler from '../utils/asyncHandler.js';
import Order from '../models/Order.js';
import Product from '../models/Product.js';
import { processSandboxPayment } from '../utils/mockPaymentGateway.js';

// @desc    Create a new order from the cart (checkout) and process sandbox payment
// @route   POST /api/orders
// @access  Private
export const addOrderItems = asyncHandler(async (req, res) => {
  const { orderItems, shippingAddress, paymentMethod, card } = req.body;

  if (!orderItems || orderItems.length === 0) {
    res.status(400);
    throw new Error('No order items. Your cart is empty.');
  }

  if (!shippingAddress || !shippingAddress.address || !shippingAddress.city) {
    res.status(400);
    throw new Error('Please provide a complete shipping address');
  }

  // Never trust prices/stock from the client — look the real products up and
  // recompute everything from what's actually in the database.
  const dbProducts = await Product.find({
    _id: { $in: orderItems.map((item) => item.product) },
  });

  let itemsPrice = 0;
  const preparedItems = orderItems.map((item) => {
    const dbProduct = dbProducts.find((p) => p._id.toString() === item.product);

    if (!dbProduct) {
      res.status(404);
      throw new Error(`Product not found: ${item.name || item.product}`);
    }
    if (dbProduct.countInStock < item.quantity) {
      res.status(400);
      throw new Error(`Not enough stock for "${dbProduct.name}" (only ${dbProduct.countInStock} left)`);
    }

    itemsPrice += dbProduct.price * item.quantity;

    return {
      name: dbProduct.name,
      quantity: item.quantity,
      image: dbProduct.image,
      price: dbProduct.price,
      product: dbProduct._id,
    };
  });

  const shippingPrice = itemsPrice > 100 ? 0 : 9.99;
  const taxPrice = Number((0.08 * itemsPrice).toFixed(2));
  const totalPrice = Number((itemsPrice + shippingPrice + taxPrice).toFixed(2));

  // Run the (simulated) sandbox payment before the order is persisted
  const paymentResult = processSandboxPayment(card);

  if (!paymentResult.success) {
    res.status(402);
    throw new Error(paymentResult.message || 'Payment failed');
  }

  const order = new Order({
    user: req.user._id,
    orderItems: preparedItems,
    shippingAddress,
    paymentMethod: paymentMethod || 'Sandbox Card',
    paymentResult: {
      id: paymentResult.id,
      status: paymentResult.status,
      cardBrand: paymentResult.cardBrand,
      last4: paymentResult.last4,
      updateTime: paymentResult.updateTime,
    },
    itemsPrice,
    shippingPrice,
    taxPrice,
    totalPrice,
    isPaid: true,
    paidAt: Date.now(),
    status: 'Processing',
  });

  const createdOrder = await order.save();

  // Reduce stock now that payment has gone through
  await Promise.all(
    preparedItems.map((item) =>
      Product.findByIdAndUpdate(item.product, { $inc: { countInStock: -item.quantity } })
    )
  );

  res.status(201).json(createdOrder);
});

// @desc    Get the logged-in user's own orders
// @route   GET /api/orders/myorders
// @access  Private
export const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
  res.json(orders);
});

// @desc    Get a single order (its owner or an admin only)
// @route   GET /api/orders/:id
// @access  Private
export const getOrderById = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id).populate('user', 'name email');

  if (!order) {
    res.status(404);
    throw new Error('Order not found');
  }

  const isOwner = order.user._id.toString() === req.user._id.toString();
  if (!isOwner && !req.user.isAdmin) {
    res.status(403);
    throw new Error('Not authorized to view this order');
  }

  res.json(order);
});

// @desc    Get every order (admin)
// @route   GET /api/orders
// @access  Private/Admin
export const getOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({}).populate('user', 'id name').sort({ createdAt: -1 });
  res.json(orders);
});

// @desc    Update an order's fulfillment status
// @route   PUT /api/orders/:id/status
// @access  Private/Admin
export const updateOrderStatus = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);

  if (!order) {
    res.status(404);
    throw new Error('Order not found');
  }

  order.status = req.body.status || order.status;

  if (req.body.status === 'Delivered') {
    order.isDelivered = true;
    order.deliveredAt = Date.now();
  }

  const updatedOrder = await order.save();
  res.json(updatedOrder);
});
