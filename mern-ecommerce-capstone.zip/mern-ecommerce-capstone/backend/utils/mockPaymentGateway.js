// A simulated sandbox / test-mode payment gateway.
//
// It mirrors how real test-mode processors behave (e.g. Stripe test cards)
// without ever contacting a real processor or persisting full card numbers
// or CVVs anywhere. Only the card brand and last 4 digits are kept, on the
// order record, purely for display on the order confirmation page.
//
// Test cards to use in the app:
//   4242 4242 4242 4242  -> payment succeeds
//   4000 0000 0000 0002  -> payment is declined
//   any other 13-19 digit number -> treated as a generic test card, succeeds
//
// To swap in a real provider's test mode later (Stripe, Razorpay, etc.),
// replace the body of processSandboxPayment with a call to that provider's
// SDK — the rest of the checkout flow (orderController.js) does not change.

const DECLINED_TEST_CARD = '4000000000000002';

export const processSandboxPayment = ({ cardNumber, cardName, expiry, cvv } = {}) => {
  const cleanedNumber = (cardNumber || '').replace(/\s+/g, '');

  if (!cleanedNumber || !cardName || !expiry || !cvv) {
    return { success: false, message: 'Missing card details. Please fill in all payment fields.' };
  }

  if (!/^\d{13,19}$/.test(cleanedNumber)) {
    return { success: false, message: 'Invalid card number. Try the sandbox test card 4242 4242 4242 4242.' };
  }

  if (!/^\d{3,4}$/.test(cvv)) {
    return { success: false, message: 'Invalid CVV.' };
  }

  if (!/^\d{2}\/\d{2}$/.test(expiry)) {
    return { success: false, message: 'Invalid expiry date. Use MM/YY.' };
  }

  if (cleanedNumber === DECLINED_TEST_CARD) {
    return {
      success: false,
      message: 'Your sandbox card was declined. Try the test card 4242 4242 4242 4242 instead.',
    };
  }

  const brand = cleanedNumber.startsWith('4')
    ? 'Visa'
    : cleanedNumber.startsWith('5')
    ? 'Mastercard'
    : 'Card';

  return {
    success: true,
    id: `SANDBOX-${Date.now()}-${Math.floor(Math.random() * 1e6)}`,
    status: 'COMPLETED',
    cardBrand: brand,
    last4: cleanedNumber.slice(-4),
    updateTime: new Date().toISOString(),
  };
};
