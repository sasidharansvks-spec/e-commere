// Wraps an async route/controller function so any rejected promise (or thrown
// error inside an async function) is forwarded to Express's error middleware,
// instead of needing a try/catch in every single controller.
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

export default asyncHandler;
