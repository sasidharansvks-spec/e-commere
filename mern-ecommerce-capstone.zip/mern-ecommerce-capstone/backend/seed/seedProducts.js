import dotenv from 'dotenv';
import connectDB from '../config/db.js';
import User from '../models/User.js';
import Product from '../models/Product.js';
import Order from '../models/Order.js';

dotenv.config();
await connectDB();

const products = [
  {
    name: 'Wireless Bluetooth Headphones',
    image: 'https://picsum.photos/seed/headphones-fes/600/600',
    description:
      'Over-ear wireless headphones with active noise cancellation, plush earcups, and up to 30 hours of battery life on a single charge.',
    category: 'Electronics',
    brand: 'SoundWave',
    price: 59.99,
    countInStock: 25,
    rating: 4.5,
    numReviews: 38,
  },
  {
    name: 'Smart Fitness Watch',
    image: 'https://picsum.photos/seed/fitness-watch-fes/600/600',
    description:
      'Track steps, heart rate, sleep, and workouts with a bright always-on display and a week-long battery life.',
    category: 'Electronics',
    brand: 'PulseFit',
    price: 89.99,
    countInStock: 15,
    rating: 4.3,
    numReviews: 24,
  },
  {
    name: 'Portable Bluetooth Speaker',
    image: 'https://picsum.photos/seed/speaker-fes/600/600',
    description:
      'Compact, splash-resistant speaker with rich, room-filling sound and 12 hours of playtime.',
    category: 'Electronics',
    brand: 'SoundWave',
    price: 34.99,
    countInStock: 30,
    rating: 4.6,
    numReviews: 51,
  },
  {
    name: "Men's Running Shoes",
    image: 'https://picsum.photos/seed/running-shoes-fes/600/600',
    description:
      'Lightweight breathable mesh running shoes with cushioned soles, built for daily training miles.',
    category: 'Fashion',
    brand: 'Stride',
    price: 49.99,
    countInStock: 20,
    rating: 4.2,
    numReviews: 19,
  },
  {
    name: "Women's Leather Handbag",
    image: 'https://picsum.photos/seed/handbag-fes/600/600',
    description:
      'A structured, genuine-leather handbag with an adjustable strap and a roomy interior for everyday essentials.',
    category: 'Fashion',
    brand: 'Marchetti',
    price: 74.99,
    countInStock: 12,
    rating: 4.7,
    numReviews: 33,
  },
  {
    name: 'Classic Cotton T-Shirt (Pack of 2)',
    image: 'https://picsum.photos/seed/tshirt-fes/600/600',
    description: 'Soft, breathable 100% cotton t-shirts in a relaxed everyday fit. Pack of 2.',
    category: 'Fashion',
    brand: 'Basics Co.',
    price: 14.99,
    countInStock: 50,
    rating: 4.1,
    numReviews: 62,
  },
  {
    name: 'Stainless Steel Water Bottle',
    image: 'https://picsum.photos/seed/bottle-fes/600/600',
    description:
      'Double-wall insulated bottle that keeps drinks cold for 24 hours or hot for 12. 750ml capacity.',
    category: 'Home & Living',
    brand: 'HydroPeak',
    price: 19.99,
    countInStock: 40,
    rating: 4.6,
    numReviews: 47,
  },
  {
    name: 'Ceramic Coffee Mug Set (Set of 4)',
    image: 'https://picsum.photos/seed/mugs-fes/600/600',
    description: 'Hand-glazed ceramic mugs in four warm tones, microwave and dishwasher safe.',
    category: 'Home & Living',
    brand: 'Hearth & Co.',
    price: 24.99,
    countInStock: 18,
    rating: 4.4,
    numReviews: 21,
  },
  {
    name: 'Modern Desk Organizer',
    image: 'https://picsum.photos/seed/desk-organizer-fes/600/600',
    description:
      'A tidy bamboo desk organizer with compartments for pens, cables, and notebooks.',
    category: 'Home & Living',
    brand: 'TidyDesk',
    price: 29.99,
    countInStock: 22,
    rating: 4.3,
    numReviews: 16,
  },
  {
    name: 'Bestselling Fiction Collection (Set of 3)',
    image: 'https://picsum.photos/seed/books-fes/600/600',
    description: 'Three acclaimed modern novels, bundled together in a single paperback set.',
    category: 'Books',
    brand: 'Harborlight Press',
    price: 27.99,
    countInStock: 10,
    rating: 4.8,
    numReviews: 29,
  },
];

const importData = async () => {
  try {
    await Order.deleteMany();
    await Product.deleteMany();
    await User.deleteMany();

    const adminUser = await User.create({
      name: 'Admin User',
      email: 'admin@example.com',
      password: 'admin123',
      isAdmin: true,
    });

    const sampleProducts = products.map((product) => ({ ...product, user: adminUser._id }));
    await Product.insertMany(sampleProducts);

    console.log('✅ Data imported successfully!');
    console.log('   Admin login -> email: admin@example.com  password: admin123');
    process.exit();
  } catch (error) {
    console.error(`Error importing data: ${error.message}`);
    process.exit(1);
  }
};

const destroyData = async () => {
  try {
    await Order.deleteMany();
    await Product.deleteMany();
    await User.deleteMany();
    console.log('🗑️  Data destroyed!');
    process.exit();
  } catch (error) {
    console.error(`Error destroying data: ${error.message}`);
    process.exit(1);
  }
};

if (process.argv[2] === '-d') {
  destroyData();
} else {
  importData();
}
